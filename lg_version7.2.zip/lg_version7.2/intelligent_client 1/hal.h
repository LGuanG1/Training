#ifndef _HAL_H_
#define _HAL_H_

extern void *hal_main(void *arg);
extern void led_ioctl(int led, int io_level);
#endif

