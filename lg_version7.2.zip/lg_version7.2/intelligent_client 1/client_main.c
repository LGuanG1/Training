#include "client_main.h"
#include "share.h"
#include "hal.h"
#include"comm.h"

struct msg_communicate server_msg_com;

int file_main( const char *s_add)
{
    struct sockaddr_in     serv_addr;
    char                   buf[MAXLINE];
    int                    sock_id;
    int                    read_len;
    int                    send_len;
    FILE                   *fp;
    int                    i_ret;
   	printf("jzr---->ADD=%s\n",s_add);
   
    //���ļ���
    /* open the file to be transported commented by guoqingbo*/
    if ((fp = fopen("/photo/1.jpg","r")) == NULL) {
        perror("Open file failed\n");
        exit(0);
    }
    
    /* create the socket commented by guoqingbo*/
    if ((sock_id = socket(AF_INET,SOCK_STREAM,0)) < 0) {
        perror("Create socket failed\n");
        exit(0);
    }
    
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;	//�̶���
    serv_addr.sin_port = htons(FILE_PORT);	//�˿ں�
    inet_pton(AF_INET, s_add, &serv_addr.sin_addr);	//ip��ַת��
   
    /* connect the server commented by guoqingbo*/
	
    i_ret = connect(sock_id, (struct sockaddr *)&serv_addr, sizeof(struct  sockaddr));//��������
    if (-1 == i_ret) {
        printf("Connect socket failed,%d\n",errno);
		
       return -1;
    }
    
    /* transported the file commented by guoqingbo*/
    //bzero(buf, MAXLINE);  //����
//****************************
	//�����ļ�
	printf("lg:-->bigan send file !\n");
	bzero(buf, MAXLINE);  //����
    while ((read_len = fread(buf, sizeof(char), MAXLINE, fp)) >0 ) {
        send_len = send(sock_id, buf, read_len, 0);
        if ( send_len < 0 ) {
            perror("Send file failed\n");
            exit(0);
        }
        bzero(buf, MAXLINE);
    }	
//********************************************	
	
    fclose(fp);
    close(sock_id);
    printf("Send Finish\n");
    return 0;
}

//�������ݰ��������
int send_msg_to_server(unsigned char type, unsigned char code, unsigned char *data, int datalen)
{
	unsigned char *out = NULL;
	int outlen = 0;
	int ret = -1;
	
    	char buf[MAXLINE];
	int                    read_len;
    	int                    send_len;
    	FILE                   *fp;
		
	pthread_mutex_lock(&socket_fd_ctd.socketfd_mt);
	if(socket_fd_ctd.socketfd_connected == -1)
	{
		client_dbg_err("send_msg_to_server--socketfd has been closed.so can not send msg to server");
        pthread_mutex_unlock(&socket_fd_ctd.socketfd_mt);
		return -1;
	}
	if(code!=ORDER_WORD_FIVE){
	client_dbg("send_msg_to_server--type=%x,code=%x",type,code);
	ret = make_msg(type, code, data, datalen, &out, &outlen);
		if(!ret)
		{
		ret = send(socket_fd_ctd.socketfd_connected,out, outlen,0);
		free_pointer(out);
        	if(ret <= 0)
			ret = -1;
		}
	}

	else{
		client_dbg("lg:[file]--type=%x,code=%x",type,code);
		file_main((const char *)&socket_fd_ctd.server_ip); //�����ļ�
		//��������(����S��ֹͣ�����̣߳�)
		ret = make_msg(type, code, data, datalen, &out, &outlen);
		if(!ret)
		{
			ret = send(socket_fd_ctd.socketfd_connected,out, outlen,0);
			free_pointer(out);
		    if(ret <= 0)
			ret = -1;
		}
	}
    
    pthread_mutex_unlock(&socket_fd_ctd.socketfd_mt);
    
	return ret;
}

int route_control_req(unsigned char *msg)
{
	unsigned char order_code;

	order_code = msg[0];
	if(order_code == ORDER_WORD_ZERO)
	{
		client_dbg("route_control_req0 %x,%x",msg[5],msg[6]);
		if(msg[5] == 0 || msg[5] == 1)
		{
			if(msg[6] == 0 || msg[6] == 1)
			{
				led_ioctl(msg[5],msg[6]);
				send_msg_to_server(ROUTE_CONTROL_ANS, ORDER_WORD_ZERO, msg+5, 2);
			}
		}

		return 0;
	}
	else if(order_code == ORDER_WORD_ONE)
	{
		client_dbg("route_control_req1 %x,%x",msg[5],msg[6]);
		if(msg[5] == 0 || msg[5] == 1)
		{
			if(msg[6] == 0 || msg[6] == 1)
			{
				led_ioctl(msg[5],msg[6]);
				send_msg_to_server(ROUTE_CONTROL_ANS, ORDER_WORD_ONE, msg+5, 2);
			}
		}

		return 0;
	}
	else if(order_code == ORDER_WORD_TWO)
	{
		client_dbg("route_control_req1 %x,%x",msg[5],msg[6]);
		if(msg[5] == 2 || msg[5] == 1)
		{
			if(msg[6] == 0 || msg[6] == 1)
			{
				led_ioctl(msg[5],msg[6]);
				send_msg_to_server(ROUTE_CONTROL_ANS, ORDER_WORD_TWO, msg+5, 2);
			}
		}

		return 0;
	}

	else if(order_code == ORDER_WORD_THREE)
	{
		client_dbg("route_control_req1 %x,%x",msg[5],msg[6]);
		if(msg[5] == 2 || msg[5] == 3)
		{
			if(msg[6] == 0 || msg[6] == 1)
			{
				led_ioctl(msg[5],msg[6]);
				send_msg_to_server(ROUTE_CONTROL_ANS, ORDER_WORD_THREE, msg+5, 2);
			}
		}

		return 0;
	}
	
	client_dbg_err("route_control_req fail");
	return 1;
}

//���շ���ͼƬ
int route_read_pic(unsigned char *msg)
{
	unsigned char order_code;
	printf("\tlg:this is control pic\n");
	order_code = msg[0];
	if(msg[6] == 1)
	{
		send_msg_to_server(ROUTE_READ_PIC_ANS, ORDER_WORD_FIVE, msg+5, 2);
		return 0;
	}
	client_dbg_err("no read file!\n");
	return 1;
}

int route_alarm_ans(unsigned char *msg)
{
	unsigned char order_code;

	order_code = msg[0];
	if(order_code == ORDER_WORD_ZERO)
	{
		client_dbg("route_alarm_ans %x,%x");

		return 0;
	}
	client_dbg_err("route_alarm_ans fail");
	return 1;
}


//�յ�����˵����ݰ��Ľ�����������
int client_msgdeal(unsigned char *msg, int len)
{
	unsigned int ret=0;
	unsigned char order_type=0;
   
	ret = unescape_msg(msg, &len);//��ת��
	if (ret != 0)
	{
		client_dbg_err("client_msgdeal--unescape_msg err");
		return -1;
	}
  
	ret = check_msg(msg, &len);//��֤��Ϣ����ȷ��
	if (ret != 0)	
	{
		client_dbg_err("client_msgdeal--check_msg err");
		return -1;	
	}
	client_dbg("client_msgdeal--order_type=%x,order_word=%x",msg[1],msg[2]);
	order_type = msg[1]; //��ȡ�������ͺ������
	client_dbg("lg:msgdeal success\n");
	switch(order_type)
	{
		case ROUTE_CONTROL_REQ:
			route_control_req(msg+2);
			break;
		case ROUTE_BEEP_REQ:
			break;
		case ROUTE_READ_PIC_REQ:
			route_read_pic(msg+2);
			break;
		default:
			break;
	}
	return 0;
}

//�ر�ָ�����׽���������
void client_close_socket(int *socket_fd)
{
    if(*socket_fd != -1)
        close(*socket_fd);

    *socket_fd = -1;
        
}

//�ر������ӵ�TCP����
void client_close_socket_ctd(void)
{
    client_dbg("client_close_socket_ctd");
    
    pthread_mutex_lock(&socket_fd_ctd.socketfd_mt);

    if(socket_fd_ctd.socketfd_connected != -1)
        close(socket_fd_ctd.socketfd_connected);
    
    pthread_mutex_unlock(&socket_fd_ctd.socketfd_mt);
    
	socket_fd_ctd.socketfd_connected = -1;
    socket_fd_ctd.socketfd_status = 0;
    socket_fd_ctd.client_registered = 0;
}

void* client_connect_main(void* para)
{
	unsigned char read_buf[512] = {0};
	int read_buf_len;
	struct sockaddr_in server_addr;

	/* ����socket������ */
	if(-1 == (socket_fd_ctd.socketfd_connected=socket(AF_INET,SOCK_STREAM,0)))
	{
		 perror("Socket Error:");
		 exit(1);
	}

	/* �ͻ��������Ҫ���ӵķ������ĵ�ַ��Ϣ�ṹ�� */
	bzero(&server_addr,sizeof(server_addr));
	server_addr.sin_family=AF_INET;
	server_addr.sin_port=htons(socket_fd_ctd.port);
	//server_addr.sin_addr=*((struct in_addr *)host->h_addr);
	server_addr.sin_addr.s_addr=inet_addr(socket_fd_ctd.server_ip);
	printf("connect=%s,%d\r\n ",socket_fd_ctd.server_ip, socket_fd_ctd.port);
	/* �ͻ��˵���connect���������������� */
	if(-1 == connect(socket_fd_ctd.socketfd_connected,(struct sockaddr *)(&server_addr),sizeof(struct sockaddr)))
	{
		 perror("Connect Error:");
		 exit(1);
	}
	while(1)
	{
		memset(read_buf, 0, sizeof(read_buf));
		read_buf_len = read(socket_fd_ctd.socketfd_connected,read_buf,sizeof(read_buf));
		if(-1 == read_buf_len){
			perror("read Error:");
		}
		client_dbg("lg:S-->C success len=%d text=[%s]\n",read_buf_len,read_buf);

		//���յ������ݷŵ���Ϣ����
		write_msg((unsigned char*)read_buf,read_buf_len);
		// ���յ������ݷŵ�����ѭ������
		//write_com(&server_msg_com, (unsigned char*)read_buf,read_buf_len);
		//client_msgdeal(read_buf, read_buf_len);
	}
   
	client_close_socket_ctd();
    	return NULL; 
}

void* client_key_main(void* para)
{

    //create_timer(&heartbeat_timer_id, heartbeat_timer_func, HEART_BEAT_KEEP, 0, 0, 1000);
	//set_timer_tm(&heartbeat_timer_id, HEART_BEAT_KEEP, 0, 0, 1000);

	return NULL;
}

int  open_server_msg_com(void)
{
	int ret = -1;
	
	ret = open_com(&server_msg_com, SERVER_MSG_MAX_LEN, SERVER_MSG_ID);
	if(ret == -1)
	{
		client_dbg_err("open_server_msg_com failed=%d", ret);
		return -1;
	}

	client_dbg("open_server_msg_com sucess !!!!!");
	return 0;
}


//�ͻ��˳�ʼ��
int client_init(int argc, char * argv[])
{
	if(argc == 3)
	{
		socket_fd_ctd.socketfd_connected = -1;
		socket_fd_ctd.socketfd_status = 0;
		pthread_mutex_init(&socket_fd_ctd.socketfd_mt, NULL);
		socket_fd_ctd.client_registered = 0;
		socket_fd_ctd.port = atoi(argv[2]);
		strcpy(socket_fd_ctd.server_ip,argv[1]);
		open_server_msg_com();
		client_dbg("client_init success, socket_fd_ctd.client_id=%s,%d",socket_fd_ctd.server_ip,socket_fd_ctd.port);

		return 0;
		
	}
	client_dbg_err("client_init fail argc=%d,argv[1]=%s",argc,argv[1]);
	return 1;
}

void client_uninit(void)
{
    close_com(&server_msg_com);
    client_close_socket_ctd();
    pthread_mutex_destroy(&socket_fd_ctd.socketfd_mt);
}

/*
���������˵����ݽ���
*/
void* client_msgdeal_main(void* para)
{
	unsigned char msg[50] = "";
	int  len = 0;
	
	while(1) 
	{
		len=read_msg(msg, len);
		if(len!=-1) //��ȡ��Ϣ����
		//if(read_com(&server_msg_com, msg, &len) == 0)
		{
			client_dbg("lg:begin write len=%d\n",len);
			client_msgdeal(msg,len);
		}
	}
 
	return NULL;
}


int main(int argc, char * argv[]) 
{ 
	pthread_t client_connect_thread,client_hal_thread,client_msgdeal_thread;
	int ret = -1;
	
	client_dbg("client main start...");
	ret=build_msg();//������Ϣ����
	if(ret==0)
	{
		printf("build the msg Y\r\n");
	}
	ret = client_init(argc,argv);
	if(ret)
	{
		client_dbg_err("client_init fail");
		return -1;
	}
	
	ret = pthread_create(&client_connect_thread,NULL,client_connect_main,NULL);
	if(ret)
	{
		client_dbg_err("pthread_create client_connect_thread fail");
		return -1;
	}
	
	ret = pthread_create(&client_msgdeal_thread,NULL,client_msgdeal_main,NULL);
	if(ret)
	{
		client_dbg_err("pthread_create client_msgdeal_thread fail");
		return -1;
	}
	
	ret = pthread_create(&client_hal_thread,NULL,hal_main,NULL);
	if(ret)
	{
		client_dbg_err("pthread_create hal_main fail");
		return -1;
	}
	
	pthread_join(client_connect_thread, NULL);
	pthread_join(client_msgdeal_thread, NULL);
	pthread_join(client_hal_thread, NULL);
    
	client_uninit();
        dle_mag();	//ɾ����Ϣ����
        client_dbg("client main end");
    	
        return 0;
	
}
