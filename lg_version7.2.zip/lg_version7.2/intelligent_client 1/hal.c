#include <pthread.h>
#include "client_main.h"
#include "share.h"

int adc_start_flag = 0;
int led_flash_flag = 0;
int button_fd, led_fd, pwm_fd;

void led_ioctl(int led, int io_level)
{
	if(led_fd >0)
	{
		ioctl(led_fd,0,0);
		ioctl(led_fd,0,1);
		ioctl(led_fd,0,2);
		ioctl(led_fd,0,3);
		ioctl(led_fd, io_level, led);
	}
	return;
}
void *thread_led(void *data)
{
	int led_fd = *(int *)data;
	while(led_flash_flag == 1)
	{//�ڶ��������������� �������������������ĸ�LED
		ioctl(led_fd, 1, 2);
		sleep(1);
		ioctl(led_fd, 0, 2);
	}

	return NULL;
}

void *thread_adc(void *data)
{
	char adc[6];
	pthread_t led_id;
	int val,adc_fd,ret;
	pthread_attr_t attr;

	pthread_attr_init( &attr );
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	
	adc_fd = open("/dev/adc",O_RDWR);
	if ( adc_fd == -1 )
	{
		printf("open dev/adc fail=%d\n",adc_fd);
		return NULL;
	}
	printf("open dev/adc success =%d\n",adc_fd);
	
	while(adc_start_flag == 1)
	{
		ret = read(adc_fd, adc, 5);
		printf("adc=%s\r\n",adc);//int a = atoi(adc); int vol = 3.3/4095*a
		val = atoi(adc);
		if(val > 1000)
		{
			if(led_flash_flag == 0)
			{
				led_flash_flag = 1;
				ioctl(pwm_fd, 1, 2000);
				pthread_create( &led_id, &attr, thread_led, NULL);
			}
		}
		else
		{
			ioctl(pwm_fd, 0, 0);
			led_flash_flag = 0;
		}
		sleep(1);
	}
	
	ioctl(pwm_fd, 0, 0);
	led_flash_flag = 0;
	close(adc_fd);

	return NULL;
}

void *hal_main(void *arg)
{
	int ret;
	
	char key[6];
	int i;
	pthread_t led_id, adc_id;
       pthread_attr_t attr;

	pthread_attr_init( &attr );
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	pwm_fd = open("/dev/pwm",O_RDWR | O_NONBLOCK);
	if ( pwm_fd == -1 ) {
		printf("open dev/pwm fail=%d\n",pwm_fd);
		return NULL;
	}

	button_fd = open("/dev/buttons",O_RDWR);
	if ( button_fd < 0 )
	{
		printf("open dev/button_fd fail=%d\n",button_fd);
		return NULL;
	}
	
	led_fd = open("/dev/leds",O_RDWR);
	if ( led_fd < 0) {
		printf("open dev/mini2440_led fail=%d\n",led_fd);
		return NULL;
	}
	
	printf("open success\n");
	
	while(1)
	{
		ret = read(button_fd, key, 6);
		for(i=0; i<ret; i++)
			printf("key[%d]=%c  ",i, key[i]);

		printf("\r\n ");

		if(key[0] == '1')
		{
			if(adc_start_flag == 0)
			{
				adc_start_flag = 1;
				pthread_create( &adc_id, &attr, thread_adc, NULL);
			}
		}
		if(key[1] == '1')
		{
			adc_start_flag = 0;
		}
		
		if(key[2] == '1')
		{
			send_msg_to_server(ROUTE_SEND_ALARM_REQ, ORDER_WORD_ZERO, NULL, 0);
		}
	}
	
	close(button_fd);
	close(led_fd);
	printf("close dev/button_fd success \n");
	
	return NULL;
}

