#ifndef _CLIENT_MAIN_H_
#define _CLIENT_MAIN_H_


#define 	SERVER_MSG_MAX_LEN        		4096
#define 	SERVER_MSG_ID     		1

extern int send_msg_to_server(unsigned char type, unsigned char code, unsigned char *data, int datalen);
#endif

