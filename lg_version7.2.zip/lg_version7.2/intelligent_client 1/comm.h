#ifndef COMM_H_
#define COMM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/ioctl.h>
#include <termios.h>
#include <math.h>
#include <pthread.h>
#include <sys/ipc.h>   
#include <sys/msg.h>
#include <errno.h>

#define MSGKEY 1024
#define 	MAXLINE		1024
#define		FILE_PORT	5888

//#define SERVER_TYPE 1
//#define CLIENT_TYPE 2

struct msgstru{
	long msgtype;
	char msgtext[2048];
};

int read_msg(unsigned char *msg, int len);
int build_msg(void);
void dle_msg(void);
int write_msg(unsigned char *msg, int  len);
int read_msg(unsigned char *msg, int len);
#endif
