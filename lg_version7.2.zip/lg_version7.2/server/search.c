#include "search.h"
#include "share.h"
#include "print.h"

/**
function������ѧ����Ϣ
parmater����
return��  ��
*/
void search_stu()
{
    char sno_tmp[5];
    char no_tmp[4];
    char sname_tmp[21];
    struct stu *tmp;
    int ch;
    
    if(record==0 && head==NULL)
    {
        show_message("Error:No record!press any key to continue....");
        wgetch(title_win);
        menu();
    }

    create_title_window("Search Menu");
    show_message("");
    wclear(main_win);
    mvwprintw(main_win,1,28,"1.Search student by sno ");
 //   mvwprintw(main_win,3,28,"2.Search student by sname");
    mvwprintw(main_win,3,28,"0.Return main menu");
    mvwprintw(main_win,5,28,"Please m ake a choices[0-1]:");	
    wrefresh(main_win);


    ch=choice_menu('1');//ѡ�����ޣ����������Ĳ˵��������йأ���ע��
    ch=ch-'0';
    switch(ch)
    {
        case SEARCH_BY_SNO://��ѧ�Ų���ѧϰ��Ϣ
            show_message("Please input student's sno[1~100]:S");
            do
            {   
                memset(no_tmp,0,sizeof(no_tmp));
                get_input_str(message_win,no_tmp,3,ASCII_TEXT);
            }while(!check_num(message_win,no_tmp));

            sno_tmp[0]='S';
            sno_tmp[1]='\0';
            strcat(sno_tmp,no_tmp);
            tmp=search_by_Sno(sno_tmp);
            print_resault(tmp);
            break;
       // case SEARCH_BY_SNAME://ѧϰ��չ������������ѧ����Ϣ
        //    break;	
        case RETURN_MAIN7 :
            menu(); 
            break;	
    }
}


/**
function��ѧ����Ϣͳ��
parmater����
return����
*/
void stat_score()
{
    int i=22;
    int ch;
    
    if(record==0 && head==NULL)
    {
        show_message("Error:No record to stat!\nPress any key to continue....");
        wgetch(title_win);
        menu();
    }
    create_title_window("Stat Menu");
    show_message("");

    wclear(main_win);
    mvwprintw(main_win,1,i,"Chin");
    mvwprintw(main_win,1,i+8,"Eng");
    mvwprintw(main_win,1,i+16,"Math");
    mvwprintw(main_win,1,i+24,"Phy");
    mvwprintw(main_win,1,i+32,"Chem");
    mvwprintw(main_win,2,i,"%.1f",get_AVG_chinese());
    mvwprintw(main_win,2,i+8,"%.1f",get_AVG_english());
    mvwprintw(main_win,2,i+16,"%.1f",get_AVG_math());
    mvwprintw(main_win,2,i+24,"%.1f",get_AVG_physics());
    mvwprintw(main_win,2,i+32,"%.1f",get_AVG_chemistry());

    mvwprintw(main_win,4,28,"1.Stat Chinese grade");
    mvwprintw(main_win,5,28,"2.Stat English grade");
    mvwprintw(main_win,6,28,"3.Stat Math grade");
    mvwprintw(main_win,7,28,"4.Stat Physics grade");
    mvwprintw(main_win,8,28,"5.Stat Chemistry grade");
    mvwprintw(main_win,9,28,"6.Stat Total grade");
    mvwprintw(main_win,10,28,"7.Stat Average grade");
    mvwprintw(main_win,11,28,"0.Return main menu");
    mvwprintw(main_win,12,28,"Please m ake a choices[0�C7]:");	
    wrefresh(main_win);

	ch=choice_menu('7');

	ch=ch-'0';
	switch(ch)
	{
		case STAT_CHINESE : 
			find_topThree(CHIN);
			print_report(list_tmp,PRINT_STAT,CHIN);
			break;

		case STAT_ENG :		
			find_topThree(ENG);
			print_report(list_tmp,PRINT_STAT,ENG);
			break;	

		case STAT_MATH : 	
			find_topThree(MATH);
			print_report(list_tmp,PRINT_STAT,MATH);
			break;

		case STAT_PHYSICS :	
			find_topThree(PHY);
			print_report(list_tmp,PRINT_STAT,PHY);
			break;	

		case STAT_CHEMISTRY :		
			find_topThree(CHEM);
			print_report(list_tmp,PRINT_STAT,CHEM); 
			break;

		case STAT_TOTAL :
			find_topThree(TOTAL);
			print_report(list_tmp,PRINT_STAT,TOTAL);
			break;

		case STAT_AVERAGE :		
			find_topThree(AVG);
			print_report(list_tmp,PRINT_STAT,AVG);
			break;
			
		case RETURN_MAIN8 :
			menu(); 
			break;	
	}
}

