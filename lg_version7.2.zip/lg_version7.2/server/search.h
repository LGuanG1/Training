#ifndef SEARCH_H_
#define SEARCH_H_


enum SEARCH_MENU{    //���Ҳ˵�
	RETURN_MAIN7,SEARCH_BY_SNO,SEARCH_BY_SNAME};

enum STAT_SCORE_MENU{//ͳ�Ʋ˵�
	RETURN_MAIN8,STAT_CHINESE,STAT_ENG,STAT_MATH,STAT_PHYSICS,
	STAT_CHEMISTRY,STAT_TOTAL,STAT_AVERAGE};

extern void stat_score();
extern void search_stu();

#endif

