#ifndef UI_H_
#define UI_H_

typedef enum tag_color
{
	BLACK_WHITE = 1,
	WHITE_BLACK,
	BLACK_BLUE,
	BLACK_RED,
	WHITE_RED,
	WHITE_BLUE,
	WHITE_CYAN
}tag_color_t;


extern void init_win();
extern void show_tips(char *s);
extern void show_message(char *s);
extern void create_title_window(char *s);
extern int choice_menu(char menu_list);
extern int choice_YorN();

#endif

