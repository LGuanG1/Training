#include "print.h"
#include "share.h"


/**
function����ӡѧ����¼
parmater��
	 head_tmp����Ҫ��ʾ������ͷָ��
	 flag����ӡ����������������
	 score_type:���ƴ�ӡ��
return����
*/
void print_report(struct stu *head_tmp,int flag,int score_type)
{	
	struct stu *p=head_tmp;
	int page=1;
	int gpage=0;
	int count=10;  //ÿҳ��¼��
	int ch;
    
	if(record==0 && head==NULL)
	{
		show_message("Error:No record!press any key to continue....");
		wgetch(title_win);
		menu();
	}
	create_title_window("Print Info");			
	
	show_message("");	
	repaint_print_win(page,flag,score_type);  
	p=print_List(p,score_type);

    wmove(main_win,13,22);	
	ch=wgetch(main_win) ;
	while(ch!=ESC)
	{
		if(KEY_NPAGE==ch)
		{
			if(p==NULL)
			{
				show_message("Note:This is the last page!");				
			}
			else
			{
				page++;
				repaint_print_win(page,flag,score_type); 
				p=print_List(p,score_type);
				show_message("");	
			}
		}
		else if(KEY_HOME==ch)
		{
			repaint_print_win(1,flag,score_type); 
			p=print_List(head_tmp,score_type);
			show_message("Note:This is the first page!");	
		}
		else if(KEY_END==ch)
		{
            page=link_length(head_tmp)/count+1;
            repaint_print_win(page,flag,score_type);
            p= get_node_by_index(head_tmp,(page-1)*count+1);
            p=print_List(p,score_type);
            show_message("Note:This is the last page!");	
		}
		else if(KEY_PPAGE==ch)
		{
			if(page==1)
			{
				show_message("Note:This is the first page!");				
			}
			else
			{
				page--;
				repaint_print_win(page,flag,score_type);
				p= get_node_by_index(head_tmp,(page-1)*count+1);
				p=print_List(p,score_type);
				show_message("");		
			}
		}
        else if(!isdigit(ch-'0'))		
		{
			gpage=ch-'0';
			 if(gpage!=page &&gpage>0  && gpage<=(link_length(head_tmp)/count+1))
			{
				page=gpage;
				repaint_print_win(page,flag,score_type);
				p= get_node_by_index(head_tmp,(page-1)*count+1);
				p=print_List(p,score_type);
				show_message("");
			}
			else if(gpage==page)
			{
				show_message("");		
			}
			else
			{
				show_message("Error:Input illegal!");		
			}
		}

		wmove(main_win,13,22);
		ch=wgetch(main_win) ;
	}
	
	if(flag==PRINT_LIST)	
		menu();//�������˵�
	else if(flag==PRINT_SORT)
		sort_data();
	else if(flag==PRINT_STAT)
		stat_score();

}

/**
function���ػ��ӡ����
parmater��
	page��Ҫ��ӡ���ǵڼ�ҳ
	flag��Ҫ��ӡ��������������������������
return����
*/
void repaint_print_win(int page,int flag,int score_type)
{
	int i=0;
	int count=10; //ÿҳ��¼��

        wclear(main_win);
        mvwprintw(main_win,i,1,"Sno");	
        mvwprintw(main_win,i,6,"Name");
	
	if(score_type==DEFAULT)
	{
		mvwprintw(main_win,i,28,"Age");
		mvwprintw(main_win,i,32,"Chine");
		mvwprintw(main_win,i,38,"Eng");
		mvwprintw(main_win,i,44,"Math");
		mvwprintw(main_win,i,50,"Phy");
		mvwprintw(main_win,i,57,"Chem");
		mvwprintw(main_win,i,65,"Total");
		mvwprintw(main_win,i,73,"Avg");  
	}
	else if(score_type==CHIN)
	{
		mvwprintw(main_win,i,32,"Chine");
	}
	else if(score_type==ENG)
	{
		mvwprintw(main_win,i,32,"Eng");
	}
	else if(score_type==MATH)
	{
		mvwprintw(main_win,i,32,"Math");
	}
	else if(score_type==PHY)
	{
		mvwprintw(main_win,i,32,"Phy");
	}
	else if(score_type==CHEM)
	{
		mvwprintw(main_win,i,32,"Chem");
	}
	else if(score_type==TOTAL)
	{
		mvwprintw(main_win,i,32,"Total");
	}
	else if(score_type==AVG)
	{
		mvwprintw(main_win,i,32,"Avg"); 
	}
	
	mvwhline(main_win,i+1,0,0,78); /*������*/
	
	if(flag==PRINT_SEARCH)
	{
		mvwprintw(main_win,12,1,"Press:[ESC] Return;[Home];[End];[PgUp]PageUp;[PgDn]PageDown;[D]del;[M]Mod");
		mvwprintw(main_win,13,5,"[1~1] GoToPage:");
		mvwprintw(main_win,13,58,"1 Records Page[1/1]");
	}
	else if(flag==PRINT_MODIFY)
	{
		mvwprintw(main_win,12,1,"Press:[0]Return; [1]name;[2]age;[3]chin;[4]eng;[5]math;[6]phy;[7]chem;"); 
		mvwprintw(main_win,13,5,"[0~7] GoToPage:");
	}
	else if(flag==PRINT_STAT)
	{
		mvwprintw(main_win,12,1,"Press:[ESC] Return; [Home] First;[End] Last;[PgUp]PageUp;[PgDn]PageDown;"); 
		mvwprintw(main_win,13,5,"[1~%d] GoToPage:",link_length(list_tmp)/count+1);
		mvwprintw(main_win,13,58,"%d Records Page[%d/%d]",link_length(list_tmp),page,link_length(list_tmp)/count+1);
	}
	else
	{
		mvwprintw(main_win,12,1,"Press:[ESC] Return; [Home] First;[End] Last;[PgUp]PageUp;[PgDn]PageDown;"); 
		mvwprintw(main_win,13,5,"[1~%d] GoToPage:",record/count+1);
		mvwprintw(main_win,13,58,"%d Records Page[%d/%d]",record,page,record/count+1);
	}
	wrefresh(main_win);
}


/**
function����ӡѧ����¼
parmater��
	 head_tmp����Ҫ��ʾ������ͷָ��
	 flag����ӡ����������������
	 score_type:���ƴ�ӡ��
return����
*/
void print_resault(struct stu *p)
{
	int page=0;
	int i=2;
	int gpage=0;
       int ch;
       
	if(p==NULL)
	{
		getyx(message_win,row,col);
		mvwprintw(message_win,row+1,0,"Have not found the student's information!\nPlease any key to continue...");
		wgetch(message_win);
		search_stu();

	}
	else
	{	
		create_title_window("Print Info");
		show_message("");
		page=1;
		repaint_print_win(page,PRINT_SEARCH,DEFAULT);

		mvwprintw(main_win,i,1,p->data.sno);	
		mvwprintw(main_win,i,6,p->data.name);	
		mvwprintw(main_win,i,28,"%2d",p->data.age);
		mvwprintw(main_win,i,32,"%.1f",p->data.chinese);
		mvwprintw(main_win,i,39,"%.1f",p->data.english);
		mvwprintw(main_win,i,44,"%.1f",p->data.math);
		mvwprintw(main_win,i,50,"%.1f",p->data.physics);
		mvwprintw(main_win,i,57,"%.1f",p->data.chemistry);
		mvwprintw(main_win,i,65,"%.1f",p->data.total);
		mvwprintw(main_win,i,73,"%.1f",p->data.avg);
		wmove(main_win,13,22);	
		
		ch=wgetch(main_win) ;
		while(ch!=ESC)
		{
			if(KEY_NPAGE==ch)
			{			
				show_message("Note:This is the last page!");				
			}
			else if('m'==ch)
			{
			}
			else if('d'==ch) /*����ĸ����d����ɾ��*/
			{	
			}
			else if(KEY_HOME==ch)
			{
				show_message("Note:This is the first page!");		
			}
			else if(KEY_END==ch)
			{
				show_message("Note:This is the last page!");		
			}
			else if(KEY_PPAGE==ch)
			{
				if(page==1)
				{
					show_message("Note:This is the first page!");				
				}
			}
			else if(!isdigit(ch-'0'))		
			{
				gpage=ch-'0';
				if(gpage==page)
				{
					show_message("");		
				}
				else
				{
					show_message("Error:Input illegal!");		
				}
			}
			wmove(main_win,13,22);
			ch=wgetch(main_win) ;
		}
		
		search_stu();//����
	}
}


/**
function����ӡҪ�޸ĵļ�¼
parmater��
	p��Ҫ�޸ĵĽڵ�
return����
*/
void print_modify(struct stu *p)
{
	int page=0;
	int i=2;
	int gpage=0;
	SNode tmp_node=p->data;
	char score[5];
	char a[3];
	int n=0;
       int ch;

	if(p==NULL)
	{
		getyx(message_win,row,col);
		mvwprintw(message_win,row+1,0,"Have not found the student's information!\nPlease any key to continue...");
		wgetch(message_win);
		search_stu();
	}
	else
	{
		create_title_window("Modify Info");
		page=1;
		repaint_print_win(page,PRINT_MODIFY,DEFAULT);
		mvwprintw(main_win,i,1,p->data.sno);	
		mvwprintw(main_win,i,6,p->data.name);	
		mvwprintw(main_win,i,28,"%2d",p->data.age);
		mvwprintw(main_win,i,32,"%.1f",p->data.chinese);
		mvwprintw(main_win,i,39,"%.1f",p->data.english);
		mvwprintw(main_win,i,44,"%.1f",p->data.math);
		mvwprintw(main_win,i,50,"%.1f",p->data.physics);
		mvwprintw(main_win,i,57,"%.1f",p->data.chemistry);
		mvwprintw(main_win,i,65,"%.1f",p->data.total);
		mvwprintw(main_win,i,73,"%.1f",p->data.avg);
		wmove(main_win,13,22);	
		
		ch=choice_menu('7');
		ch=ch-'0';
		switch(ch)
		{
		case NAME :
			show_message("please input new name:");	  
			do
			{
				memset(tmp_node.name,0,sizeof(tmp_node.name));
				get_input_str(message_win,tmp_node.name,20,ASCII_TEXT);	
			}while(!check_name(message_win,tmp_node.name));	
			break;

		case AGE :
			show_message("please input new age:");	  
			do
			{  
				memset(a,0,sizeof(a));
				get_input_str(message_win,a,3,ASCII_TEXT);
			}while(!check_age(message_win,a));
			tmp_node.age=atoi(a);
			break;

		case CHIN_S : 
			show_message("please input chinese score:");	
			do
			{		
				memset(score,0,sizeof(score));
				get_input_str(message_win,score,20,ASCII_TEXT);	
			}while(!check_score(message_win,score));	
			tmp_node.total-=tmp_node.chinese;		
			tmp_node.chinese=(float)atof(score);
			tmp_node.total+=tmp_node.chinese;
			tmp_node.avg=tmp_node.total/5;
			break;

		case ENG_S :
			show_message("please input English score:");	
			do
			{				
				memset(score,0,sizeof(score));
				get_input_str(message_win,score,20,ASCII_TEXT);	
			}while(!check_score(message_win,score));	
			tmp_node.total-=tmp_node.english;	
			tmp_node.english=(float)atof(score);
			tmp_node.total+=tmp_node.english;
			tmp_node.avg=tmp_node.total/5;
			break;
			
		case MATH_S : 	
			show_message("please input Math score:");	
			do
			{
				memset(score,0,sizeof(score));
				get_input_str(message_win,score,20,ASCII_TEXT);	
			}while(!check_score(message_win,score));	
			tmp_node.total-=tmp_node.math;		
			tmp_node.math=(float)atof(score);
			tmp_node.total+=tmp_node.math;
			tmp_node.avg=tmp_node.total/5;
			break;
			
		case PHY_S :	
			show_message("please input physics score:");	
			do
			{
				memset(score,0,sizeof(score));
				get_input_str(message_win,score,20,ASCII_TEXT);	
			}while(!check_score(message_win,score));	
			tmp_node.total-=tmp_node.physics;		
			tmp_node.physics=(float)atof(score);
			tmp_node.total+=tmp_node.physics;
			tmp_node.avg=tmp_node.total/5;
			break;
			
		case CHEM_S :		
			show_message("please input chemistry score:");	
			do
			{			
				memset(score,0,sizeof(score));
				get_input_str(message_win,score,20,ASCII_TEXT);	
			}while(!check_score(message_win,score));	
			
			tmp_node.total-=tmp_node.chemistry;	
			tmp_node.chemistry=(float)atof(score);
			tmp_node.total+=tmp_node.chemistry;
			tmp_node.avg=tmp_node.total/5;
			break;
			
		case BACK :
			print_resault(p);
			break;	
		}
			
		update_node(p,tmp_node);
		
		getyx(message_win,row,col);
		mvwprintw(message_win,3,0,"Modify success!");
		wrefresh(message_win);
		
		print_modify(p);
	}		
}

