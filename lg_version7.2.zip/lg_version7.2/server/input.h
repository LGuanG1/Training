#ifndef INPUT_H_
#define INPUT_H_

#include "share.h"

extern int get_input_str(WINDOW *win_tmp,char str[],int max_len,int flag);
extern void goback_n(WINDOW *win_tmp,int n);
extern void delete_leftspace(char *str);
extern void delete_rightspace(char *str);
extern void delete_space(char *str);

#endif

