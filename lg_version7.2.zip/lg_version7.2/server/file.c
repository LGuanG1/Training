#include "file.h"

char savefilename[9]="";

/**
function����¼����Ϊ
parmater��
	 flag������˳�ǰ���棬���ǳ������м䱣��
return����
*/
void save_as_file(int flag)	
{
	
	char filename[29]="";
	
	if(record==0 && head==NULL)
	{
		show_message("Error:No record to save!\nPress any key to continue....");
		wgetch(title_win);
		menu();
	}
	create_title_window("Save Info");	
	show_message("");

	wclear(main_win);  
	mvwprintw(main_win,12,3,"[File name not include ( \\ : *  ?  \"  < > |)]");
	mvwprintw(main_win,13,3,"[The length of  file name not more than 8 ]");
    mvwprintw(main_win,1,3,"Press [ESC] to cancel!");
	mvwprintw(main_win,3,3,"Please input the file path:");
 
	wrefresh(main_win);
	
	do
	{
		get_input_str(main_win,filename,28,ASCII_TEXT);
	}
	while (!check_filename(filename,CHECK_SAVE));

	save_toFile(filename);	
	show_message("Note:Save SUCCESS! Press any key to continue...");
	wgetch(title_win);
	
	if(flag==SAVE_BEFORE)
		menu();
	 else if(flag==SAVE_EXIT)
	 {
		 free_List();
		 endwin();
		 exit(0);
	 }
}

/**
function����¼���浽�ļ�
parmater����
return��  ��
*/
void save_to_file()
{	
    if(record==0 && head==NULL)
    {
        show_message("Error:No record to save!\nPress any key to continue....");
        wgetch(title_win);
        menu();
    }

    /*��һ�α���ʱ��δ�����ļ���*/
    if(strlen(savefilename)==0)
    {
        create_title_window("Save Info");	
        show_message("");

        wclear(main_win);  
        mvwprintw(main_win,12,3,"[File name not include ( \\ : *  ?  \"  < > |)]");
        mvwprintw(main_win,13,3,"[The length of  file name not more than 8 ]");
        mvwprintw(main_win,1,3,"This is the first time to save this file!");
        mvwprintw(main_win,2,3,"Press [ESC] to cancel!");
        mvwprintw(main_win,3,3,"Please input the file path:");

        wrefresh(main_win);
        do
        {
            get_input_str(main_win,savefilename,28,ASCII_TEXT);
        }
        while (!check_filename(savefilename,CHECK_SAVE));

     }

    save_toFile(savefilename);	
    show_message("Note:Save SUCCESS ! Press any key to continue...");
    wgetch(title_win);

    menu();
}

/**
function�����ļ���ȡ����
parmater����
return��  ��
*/
void load_data()
{
    create_title_window("Load Menu");	
    show_message("");

    wclear(main_win);
    mvwprintw(main_win,1,28,"1.Load from default file ");
   // mvwprintw(main_win,3,28,"2.Load from other path file");
    mvwprintw(main_win,3,28,"0.Return main menu");
    mvwprintw(main_win,5,28,"Please make a choices[0-1]:");	
    wrefresh(main_win);

    ch=choice_menu('1');//ѡ�����ޣ����������Ĳ˵��������йأ���ע��
    ch=ch-'0';
    switch(ch)
    {
        case FROM_DEFAULT_FILE : 
            read_fromFile(DEFAULT_FILE);//��Ĭ���ļ�DEFAULT_FILE��ȡ���ݵ�����head��
            show_message("Note: Read records success!\nPress any key to continue...");
            wgetch(title_win);
            menu();
            break;
      //  case FROM_OTHER_FILE ://ѧϰ��չ��ʵ���û��Զ����ȡָ���ļ�������ݵ�����head��
       //     break;	
        case RETURN_MAIN6 :
            menu(); 
            break;
    }
}

/**
function����ָ���ļ���ȡ����
parmater����
return��  ��
*/
void load_from_other()
{
    char filename[9]="";

    create_title_window("Load Info");	
    show_message("");

    wclear(main_win);  
    mvwprintw(main_win,12,3,"[File name not include (  \\ : *  ?  \"  < > |)]");
    mvwprintw(main_win,13,3,"[The length of  file name not more than 8 ]");
    mvwprintw(main_win,1,3,"Press [ESC] to cancel!");
    mvwprintw(main_win,3,3,"Please input the file path:");

    wrefresh(main_win);	
    do
    {
        get_input_str(main_win,filename,28,ASCII_TEXT);
    }
    while (!check_filename(filename,CHECK_LOAD));

    read_fromFile(filename);
    show_message("Note: Read records success!\nPress any key to continue...");
    wgetch(title_win);
    menu();
}


/**
function���������浽�ļ�
parmater��
	filename�����浽���ļ���
return����
*/
void save_toFile(char *filename)
{
	FILE *fp=NULL;
	isSave=0;

	struct stu *p=head;

	if(access(filename,F_OK)==0)
		fp=fopen(filename,"r+b");
	else
		fp=fopen(filename,"w+b");
	while(p!=NULL)
	{
		fwrite(p,sizeof(struct stu),1,fp);
		p=p->next;
	}
	fclose(fp);
}

/**
function�����ļ���������
parmater:
		filename:Ҫ������ļ���
return: ��
*/
void read_fromFile(char *filename)
{
  
	FILE *fp=NULL;
	struct stu *tmp=NULL;	
	struct stu *info=(struct stu *)malloc(sizeof(struct stu));
	  
	free_List();//�ͷ�����
	head=NULL;
 
   if(access(filename,F_OK)==0)
	{
	   fp=fopen(filename,"r+b");
	   memset(info,0,sizeof(struct stu));
	   while((fread(info,sizeof(struct stu),1,fp))>0)
		{			 
			if(head==NULL)
			{
				head=info;
				head->next=NULL;
				head->prior=NULL;	
				tmp=head;
			}
			else
			{		
				info->next=NULL;
				info->prior=tmp;	
				tmp->next=info;
				tmp=tmp->next;
			}
			record++;
			info=(struct stu *)malloc(sizeof(struct stu));
			memset(info,0,sizeof(struct stu));		
		}
		fclose(fp);	
	}
	else
	{
		show_message("Error: The file is not exist!\nPress any key to continue...");
		wgetch(message_win);
	}		
}



/**
function�������¼���˳�
parmater����
return����
*/
void save_data()
{
    int ch;
	create_title_window("Load Menu");	
	show_message("");

	wclear(main_win);
	mvwprintw(main_win,1,28,"1.Save data to default file ");
	//mvwprintw(main_win,3,28,"2.Save data to other file");
	mvwprintw(main_win,3,28,"0.Return main menu");
	mvwprintw(main_win,5,28,"Please make a choices[0-1]:");	
	wrefresh(main_win);

	ch=choice_menu('1');
	ch=ch-'0';
	switch(ch)
	{
		case TO_DEFAULT_FILE : 
            save_toFile(DEFAULT_FILE);//�������ݵ�Ĭ���ļ�DEFAULT_FILE
            show_message("Note:Save SUCCESS! Press any key to continue...");
            wgetch(title_win);
            free_List();
            endwin();
            exit(0);
			break;
		//case TO_OTHER_FILE ://ѧϰ��չ��ʵ���û������Զ��屣�����ݵ��ĸ��ļ�
		//	break;	
		case RETURN_MAIN1 :
			menu(); 
			break;
	}
}


int add_to_log_file(char *fmt,...)
{
	int ret;
	FILE *pfile= NULL;	
	va_list ap;
	char uch_Buf[800];
	time_t now;
	struct tm *p_time;

       pfile = fopen(LOG_FILE, "ab+");  
	if(pfile == NULL)
	{
		return -1;
	}
	time(&now);
	p_time = (struct tm *)localtime(&now);
	
	memset(uch_Buf,0,800);

	va_start(ap, fmt);
	vsprintf(uch_Buf, fmt, ap);
	va_end(ap);
	//printf("\n(SERVER##%d:%d:%d)%s\n", p_time->tm_hour, p_time->tm_min, p_time->tm_sec, uch_Buf);
	//strcpy(uch_Buf+strlen(uch_Buf), "\r\n");
	ret = fwrite(uch_Buf, strlen(uch_Buf)+1, 1, pfile);//д����
	//if(ret > 0)
	//	printf("Success to add student infomation to system\r\n");
	//else
	//	printf("Fail to add student infomation to system\r\n");

	fclose(pfile);	  
	return 0;
}


