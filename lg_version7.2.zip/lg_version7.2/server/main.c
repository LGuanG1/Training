


#include "ui.h"
#include "list.h"
#include "add.h"
#include "search.h"
#include "input.h"
#include "sort.h"
#include "share.h"
#include "file.h"
#include "print.h"


void create_frame();
void  user_login();
void menu();
void exit_sys();
void * file_thread(void *arg);

/**
function����������ܽ���          
parmater����
return����
*/
void create_frame()
{   	
    win=newwin(29,80,0,0);         //��ܴ���
    title_win=newwin(3,20,1,28);   //���ⴰ��
    main_win=newwin(14,78,4,1);    //�����洰��
    message_win=newwin(4,78,19,1); //��ʾ��Ϣ����
    tips_win=newwin(4,78,24,1); //�ͻ����������͹�����Ϣ����ʾ��

    wbkgd(win,COLOR_PAIR(WHITE_BLUE));//�趨������ɫ
    wbkgd(title_win,COLOR_PAIR(WHITE_RED));
    wbkgd(main_win,COLOR_PAIR(WHITE_BLUE));
    wbkgd(message_win,COLOR_PAIR(WHITE_CYAN));
    wbkgd(tips_win,COLOR_PAIR(WHITE_CYAN));

    /*������keypad�ᣬ����ʹ�ü����ϵ�һЩ������Ԫ�����������ҵȷ����
	���ô���֧�ּ��̵������¼����������а������£�����ô����¿���ͨ��wgetch����
	����ȡ�û������ĸ�����*/
    keypad(main_win,true);
    keypad(message_win,true);

    box(win,0,0);                  //�����ܱ߿�
    mvwprintw(win,0,25,"Intelligent System");

    /*������*/
    mvwaddch(win,18,0,ACS_LTEE);
    mvwhline(win,18,1,0,78);
    mvwaddch(win,18,79,ACS_RTEE);
    mvwprintw(win,18,36,"Message");
	
    mvwaddch(win,23,0,ACS_LTEE);
    mvwhline(win,23,1,0,78);
    mvwaddch(win,23,79,ACS_RTEE);
    mvwprintw(win,23,36,"Client Tips");

    wrefresh(win);
}


/**
function����¼       
parmater����
return����
*/
void  user_login()	
{  
	char username[11]="";
	char password[6]=""; 
	int count=3;
	int n=0;

	wrefresh(main_win);
	mvwprintw(main_win,1,13,"UserName:");
	mvwprintw(main_win,1,40,"[The max length of username is 10]");
	mvwprintw(main_win,3,13,"Password:");
	mvwprintw(main_win,3,40,"[The  length of password is 6]");

	show_message("Please input username!");
	show_tips("no client info");
	wrefresh(main_win);	// ˢ��ָ�����ڲ�����ʾ������ʾ
	wmove(main_win,1,22);//�ƶ���굽ָ�����ڵ�ָ��λ��
	do //��֤�û����Ƿ�Ϊ��admin��
	{		
		if(strcmp("",username))
		{
			show_message("Error:User if not exist!\nplease input username again!");
		    wrefresh(message_win); 
			goback_n(main_win,n);
		}	
		n=get_input_str(main_win,username,10,NORMAL_TEXT);
		delete_space(username); //ȥ�����ҿո�
	}while(strcmp("liguang",username));

	goback_n(main_win,n);
	wprintw(main_win,username);
	wrefresh(main_win);

	show_message("Please input password!");
	wmove(main_win,3,22); 

	/*��֤�����Ƿ�Ϊ��123456��*/
	do
	{
		if(!(count--)) /*�����������*/
		{
			endwin();
			exit(0);
		}
		if(strcmp("",password))
		{
			if(count==1)
				show_message("Error:The passwd id wrong!you have 2 chances left!!\nplease input password again!");
			if(count==0)
				show_message("Error:The passwd id wrong!you have last chance left!!\nplease input password again!");
		    wrefresh(message_win); 
			goback_n(main_win,n);
		}
		n=get_input_str(main_win,password,6,PASSWORD_TEXT);	
	}while(strcmp("123456",password));
	wrefresh(main_win);
}


void car_forward() 	
{
	int i=0,n=0;
	char door_control[6];
	int ch;
	
	create_title_window("Car_forward");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	wrefresh(main_win);
	
	show_message("Please input 1 to open or 0 to close");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(door_control,0,sizeof(door_control));
		n=get_input_str(main_win,door_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,door_control)); 

	door_control[1] = door_control[0]-0x30;
	door_control[0] = 0;
	send_msg_to_client(ROUTE_CONTROL_REQ, ORDER_WORD_ZERO,door_control, 2);
	
	wrefresh(main_win); 
	
	show_message("car_forward success!\nDo you want to car_forward again ?[y/n]:");
	
	ch=choice_YorN();
	if('y'==ch)
		car_forward();
	else 
		menu();
}

void car_left() 	
{
	int i=0,n=0;
	char door_control[6];
	int ch;
	
	create_title_window("Car_left");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	wrefresh(main_win);
	
	show_message("Please input 1 to open or 0 to close");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(door_control,0,sizeof(door_control));
		n=get_input_str(main_win,door_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,door_control)); 

	door_control[1] = door_control[0]-0x30;
	door_control[0] = 2;
	send_msg_to_client(ROUTE_CONTROL_REQ, ORDER_WORD_TWO,door_control, 2);
	
	wrefresh(main_win); 
	
	show_message("car_left success!\nDo you want to car_left again ?[y/n]:");
	
	ch=choice_YorN();
	if('y'==ch)
		car_left();
	else 
		menu();
}

void car_right() 	
{
	int i=0,n=0;
	char door_control[6];
	int ch;
	
	create_title_window("Car_right");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	wrefresh(main_win);
	
	show_message("Please input 1 to open or 0 to close");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(door_control,0,sizeof(door_control));
		n=get_input_str(main_win,door_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,door_control)); 

	door_control[1] = door_control[0]-0x30;
	door_control[0] = 3;
	send_msg_to_client(ROUTE_CONTROL_REQ, ORDER_WORD_THREE,door_control, 2);
	
	wrefresh(main_win); 
	
	show_message("car_right success!\nDo you want to car_right again ?[y/n]:");
	
	ch=choice_YorN();
	if('y'==ch)
		car_right();
	else 
		menu();
}

void car_backward() 	
{
	int i=0,n=0;
	char door_control[6];
	int ch;
	
	create_title_window("Car_backward");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	wrefresh(main_win);
	
	show_message("Please input 1 to open or 0 to close");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(door_control,0,sizeof(door_control));
		n=get_input_str(main_win,door_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,door_control)); 

	door_control[1] = door_control[0]-0x30;
	door_control[0] = 1;
	send_msg_to_client(ROUTE_CONTROL_REQ, ORDER_WORD_ONE,door_control, 2);
	
	wrefresh(main_win); 
	
	show_message("car_backward success!\nDo you want to car_backward again ?[y/n]:");
	
	ch=choice_YorN();
	if('y'==ch)
		car_backward();
	else 
		menu();
}

/*void read_photo() 	
{
	int i=0,n=0;
	char door_control[6];
	int ch;
	
	create_title_window("Read Photo");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	wrefresh(main_win);
	
	show_message("Please input 1 to open or 0 to close");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(door_control,0,sizeof(door_control));
		n=get_input_str(main_win,door_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,door_control)); 

	door_control[1] = door_control[0]-0x30;//����
	door_control[0] = 4;//��ȡ��Ƭ
	send_msg_to_client(ROUTE_CONTROL_REQ, ORDER_WORD_FOUR,door_control, 2);
	
	wrefresh(main_win); 
	
	show_message("Read photo success!\nExit ?[y/n]:");
	
	ch=choice_YorN();
	if('y'==ch)
		menu();
	else 
		menu();
}
*/
void read_photo() 	
{
	int i=0,n=0;
	char lg_control[6];
	int ch;
	pthread_t file_tid;	//�ļ��̱߳�־
	
	create_title_window("Read_Photo");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	mvwprintw(main_win,2,22,"Hint: [0]NO");
	mvwprintw(main_win,3,22,"      [1]YES");
	wrefresh(main_win);
	
	show_message("Please input 1 to rend file or 0 to no");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(lg_control,0,sizeof(lg_control));
		n=get_input_str(main_win,lg_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,lg_control)); 

	lg_control[1] = lg_control[0]-0x30;
	lg_control[0] = 0;
	send_msg_to_client(ROUTE_READ_PIC_REQ, ORDER_WORD_FIVE,lg_control, 2);

	pthread_create(&file_tid, NULL, file_thread, NULL);//�����ļ�����,�����ļ�

	show_message("read_file transmission ing......\n");
	wrefresh(main_win);
	
	show_message("read_file success!-->cd pwd :1.jpg\nDo you want to read_file again ?[y/n]:");	
	ch=choice_YorN();
	if('y'==ch)
		menu();
	else 
		menu();
}


void control_windows() 	
{
	int i=0,n=0;
	char door_control[6];
	int ch;
	
	create_title_window("Control Windows");
	wclear(main_win);	
	mvwprintw(main_win,1,22,"Op:");
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	wrefresh(main_win);
	
	show_message("Please input 1 to open or 0 to close");
	wrefresh(message_win); 
	wmove(main_win,1,26);
	do
	{
		memset(door_control,0,sizeof(door_control));
		n=get_input_str(main_win,door_control,5,ASCII_TEXT);	
	}while(!check_led_control(main_win,door_control)); 

	door_control[1] = door_control[0]-0x30;//����
	door_control[0] = 1;//�ĸ�LED
	send_msg_to_client(ROUTE_CONTROL_REQ, ORDER_WORD_ONE,door_control, 2);
	
	wrefresh(main_win); 
	
	show_message("car_forward success!\nDo you want to car_forward again ?[y/n]:");
	
	ch=choice_YorN();
	if('y'==ch)
		car_forward();
	else 
		menu();
}


/*���˵�*/
void menu()
{
	
	int ch;
	create_title_window("In Server");	
	show_message("Welcome To Intelligent Server System!");
	
	wclear(main_win);
	mvwprintw(main_win,1,28,"1.control car left");//Զ�̲ٿ�LED2 ģ��С������ת
	mvwprintw(main_win,2,28,"2.control car backward");//Զ�̲ٿ�LED1 ģ��С�������
	mvwprintw(main_win,3,28,"3.control car right");//Զ�̲ٿ�LED3 ģ��С������ת
	mvwprintw(main_win,4,28,"4.read photo");//��ȡͼƬ
	mvwprintw(main_win,5,28,"5.control car forward");//Զ�̲ٿ�LED0 ģ��С����ǰ��
	mvwprintw(main_win,6,28,"6.read log");//��ȡ����������Ĳ�����־
	mvwprintw(main_win,7,28,"0.Exit");
	mvwprintw(main_win,8,28,"Please Make a choices[0-6]:");	
	wrefresh(main_win);

	ch=choice_menu('6');
	ch=ch-'0';
	switch(ch)
	{
		case CAR_LEFT: 
			car_left();
			break;
		case CAR_BACKWARD : 
			car_backward();
			break;
		case CAR_RIGHT :
			car_right();
			break;	
		case READ_PHOTO :
			read_photo();
			break;
		case CAR_FORWARD :
			car_forward();
			break;
		case READ_LOG:
			break;
		case MENU_EXIT :
			exit_sys();   
			break;	
	}

}

/**
function���˳�ϵͳ����,δ����ʱ�����Ѻ���ʾ
parmater����
return����
*/
void exit_sys()
{	
	int ch;
	create_title_window("Exit Menu");
	show_message("");

	wclear(main_win);
	if(isSave==1)
	{
		show_message("Warning: infomation have not saved!");
		mvwprintw(main_win,1,28,"2.Save and exit ");
	}
	mvwprintw(main_win,3,28,"1.Exit system");
	mvwprintw(main_win,5,28,"0.Return main menu");

	if(isSave==1)
	{
		mvwprintw(main_win,7,28,"Please make a choices[0-2]:");	
		wrefresh(main_win);
		ch=choice_menu('2');
	}
	else
	{
		mvwprintw(main_win,7,28,"Please make a choices[0-1]:");	
		wrefresh(main_win);
		ch=choice_menu('1');
	}
  

	ch=ch-'0';
	switch(ch)
	{
		case SAVE_AND_EXIT : 
			save_data();
			break;
		case EXIT :
			free_List();
			endwin();
		    exit(0);
			break;	
		case RETURN_MAIN :
			menu(); 
			break;	
	}
}

/*������*/
int main(int argc, char *argv[]) 
{
    init_win();    //��ʼ������
    create_frame();
    create_title_window("User Login"); 	

    user_login();  //��¼
    
    if(tcp_server(argc, argv) != 0)
    {
    	goto fail;
    }

    menu();        //���˵�
fail:
    free_List();
    endwin();
    return 0;
}

