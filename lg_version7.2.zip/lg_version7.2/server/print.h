#ifndef PRINT_H_
#define PRINT_H_

#include "list.h"

enum PRINT_FLAG{PRINT_LIST,PRINT_SORT,PRINT_SEARCH,PRINT_STAT,PRINT_MODIFY};//��ӡ����

extern void print_report(struct stu *head_tmp,int flag,int score_type);
extern void repaint_print_win(int page,int flag,int score_type);
extern void print_resault(struct stu *p);
extern void print_modify(struct stu *p);

#endif

