#include "share.h"
#include "file.h"

#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <pthread.h>

#include"comm.h"
#define		FILE_PORT		5888
int exit_flag = 0;
int client_fd;



//ssize_t s;

struct msg_communicate server_msg_com;

//��������ָ���Ŀͻ���
int send_msg_to_client(unsigned char type, unsigned char code, unsigned char *data, int datalen)
{

	//int msgid = createMsgQueue();
	
	unsigned char *out = NULL;
	int outlen = 0;
	int ret = -1;
//����в�ͬ���̵߳���send_msg_to_client����������
	if(client_fd == -1)
		return 1;

	server_dbg("send_msg_to_client--type=%x,code=%x\r\n",type,code);
	ret = make_msg(type, code, data, datalen, &out, &outlen);
	//printf("ret= ",ret);
	if(!ret)
	{
		ret = write(client_fd,out, outlen);
		//ret = sendMsg(msgid, SERVER_TYPE, out);
		//printf("send done,wait recv...\n");
		
		if(out != NULL)
		{
			free(out);
			out = NULL;
		}
		if(ret <=0)
			ret = -1;
	}
	//destroyMsgQueue(msgid);
	return ret;
}

int client_car_forward_ans(unsigned char *msg)
{
	int i = 0;
	unsigned char res = 0x00;
	unsigned char order_code;
	char client_id[20] = {0};

	order_code = msg[0];
	if(order_code == ORDER_WORD_ZERO)
	{
		server_dbg("client_car_forward_ans %d,%d\r\n",msg[5], msg[6]);
	}
	//else if(order_code == ORDER_WORD_ONE)
	//{
	//	server_dbg("client_control_windows_ans %d,%d\r\n",msg[5], msg[6]);
	//}

	return 0;
}

int client_car_backward_ans(unsigned char *msg)
{
	int i = 0;
	unsigned char res = 0x00;
	unsigned char order_code;
	char client_id[20] = {0};

	order_code = msg[0];
	if(order_code == ORDER_WORD_ONE)
	{
		server_dbg("client_car_backward_ans %d,%d\r\n",msg[5], msg[6]);
	}
	//else if(order_code == ORDER_WORD_ONE)
	//{
	//	server_dbg("client_control_windows_ans %d,%d\r\n",msg[5], msg[6]);
	//}

	return 0;
}

int client_car_right_ans(unsigned char *msg)
{
	int i = 0;
	unsigned char res = 0x00;
	unsigned char order_code;
	char client_id[20] = {0};

	order_code = msg[0];
	if(order_code == ORDER_WORD_THREE)
	{
		server_dbg("client_car_right_ans %d,%d\r\n",msg[5], msg[6]);
	}
	//else if(order_code == ORDER_WORD_ONE)
	//{
	//	server_dbg("client_control_windows_ans %d,%d\r\n",msg[5], msg[6]);
	//}

	return 0;
}

int client_car_left_ans(unsigned char *msg)
{
	int i = 0;
	unsigned char res = 0x00;
	unsigned char order_code;
	char client_id[20] = {0};

	order_code = msg[0];
	if(order_code == ORDER_WORD_TWO)
	{
		server_dbg("client_car_left_ans %d,%d\r\n",msg[5], msg[6]);
	}
	//else if(order_code == ORDER_WORD_ONE)
	//{
	//	server_dbg("client_control_windows_ans %d,%d\r\n",msg[5], msg[6]);
	//}

	return 0;
}

//��ȡ��Ƭ	
int client_read_pic_ans(unsigned char *msg)
{
	int i = 0;
	unsigned char res = 0x00;
	unsigned char order_code;
	char client_id[20] = {0};

	order_code = msg[0];
	if(order_code == ORDER_WORD_FIVE)
	{
		server_dbg("client_read_pic_ans %d,%d\r\n",msg[5], msg[6]);
		show_tips("File, success!");
	}
	//else if(order_code == ORDER_WORD_ONE)
	//{
	//	server_dbg("client_control_windows_ans %d,%d\r\n",msg[5], msg[6]);
	//}

	return 0;
}


//�յ��ͻ������ݵĽ�������
int server_msgdeal(unsigned char *msg, int len)
{
	unsigned int ret=0;
	unsigned char order_type=0;

	//buffer[0] = 0;

	ret = unescape_msg(msg, &len);//��ת��
	if (ret != 0)
	{
		server_dbg_err("server_msgdeal--unescape_msg err\r\n");
		return -1;
	}

	ret = check_msg(msg, &len);//��֤��Ϣ����ȷ��
	if (ret != 0)	
	{
		server_dbg_err("server_msgdeal--check_msg err\r\n");
		return -1;	
	}
	server_dbg("server_msgdeal--order_type=%x,order_word=%x\r\n",msg[1],msg[2]);
	order_type = msg[1]; //��ȡ�������ͺ�������
	switch(order_type)
	{
		case ROUTE_CARLEFT_ANS:
			client_car_left_ans(msg+2);
			break;
		case ROUTE_CARBACKWARD_ANS:
			client_car_backward_ans(msg+2);
			break;
		case ROUTE_CATRIGHT_ANS:
			client_car_right_ans(msg+2);
			break;
		case ROUTE_CARFORWARD_ANS:
			client_car_backward_ans(msg+2);
		case ROUTE_READ_PIC_ANS:
			client_read_pic_ans(msg+2);
		default:
			break;
	}
	return 0;
}

void *server_main(void *arg)
{
	int skfd,addr_len,read_buf_len;
	struct sockaddr_in srv_addr,clt_addr;
	char read_buf[512]={0};
	int portnumber = *(int *)arg;

	//int msgid = createMsgQueue();//��Ϣ���еĴ���
	//char buffer[1024];

	if(-1 == (skfd=socket(AF_INET,SOCK_STREAM,0)))
	{
	     server_dbg_err("Socket Error\r\n");
	     exit_flag = -1;
	     return NULL;
	}

	/* ����������sockaddr��ַ�ṹ */
	bzero(&srv_addr,sizeof(struct sockaddr_in));
	srv_addr.sin_family=AF_INET;
	srv_addr.sin_addr.s_addr=htonl(INADDR_ANY);
	srv_addr.sin_port=htons(portnumber);

	/* ���׽���������skfd�͵�ַ��Ϣ�ṹ������� */
	if(-1 == bind(skfd,(struct sockaddr *)(&srv_addr),sizeof(struct sockaddr)))
	{
	     server_dbg_err("Bind error\r\n");
	     exit_flag = -1;
	     return NULL;
	}

	/* ��skfdת��Ϊ������ͨģʽ */
	if(-1 == listen(skfd,4))
	{
	     server_dbg_err("Listen error\r\n");
	     exit_flag = -1;
	     return NULL;
	}
	
	server_dbg("accept to wait client to connect\n"); 
	/* ����accept,��������һֱ������ֱ���ͻ��������佨�����ӳɹ�Ϊֹ*/
	addr_len=sizeof(struct sockaddr_in);
	if(-1 == (client_fd=accept(skfd,(struct sockaddr *)(&clt_addr),&addr_len))) 
	//cnfd�������������Ŀͻ��˵���·��ʶ��
	{
		 server_dbg_err("Accept error\r\n");
		 exit_flag = -1;
		 return NULL;
	}
	server_dbg("Connect from %s:%u ...!\n",inet_ntoa(clt_addr.sin_addr),ntohs(clt_addr.sin_port)); 
	
	while(1)
	{
           	read_buf_len = read(client_fd,read_buf,sizeof(read_buf));
           	//read_buf[0] = 0;
           	//read_buf_len = recvMsg(msgid, CLIENT_TYPE, read_buf);
	   	//printf("recv from client# %s\n",read_buf);
		   
	    	if(-1 ==read_buf_len){
	       		server_dbg_err("read error\r\n");
		  	exit_flag = -1;
	         	return NULL;
	    	}
			
	    server_msgdeal(read_buf, read_buf_len);
	}

	close(client_fd);
	close(skfd);
	//destroyMsgQueue(msgid);
	return NULL;
}

int tcp_server(int argc, char *argv[])//./tcp_server 1234
{
	int portnumber;
	pthread_t server_read_id;
	pthread_attr_t attr;

	if(2 != argc || 0 > (portnumber=atoi(argv[1])))
	{
	     printf("Usage:%s port\n",argv[0]);
	     return -1;
	}

	pthread_attr_init( &attr );
    	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
       exit_flag = pthread_create( &server_read_id, &attr, server_main, &portnumber );
	sleep(1);
	
	server_dbg("tcp_server exit %d\n",exit_flag);

	return exit_flag;
	
}


void * file_thread(void *arg)
{
    struct sockaddr_in     serv_addr;
    struct sockaddr_in     clie_addr;
    char                   buf[MAXLINE];
    int                    sock_id;
    int                    link_id;
    int                    recv_len;
    int                    write_leng;
    int                    clie_addr_len;
    FILE                   *fp;
 


    if ((sock_id = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Create socket failed\n");
        exit(0);
    }
    /*fill the server sockaddr_in struct commented by guoqingbo*/
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(FILE_PORT);
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
 
    if (bind(sock_id, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0 ) {
        perror("Bind socket failed\n");
        exit(0);
    }
 //show_message("lg-->listen bigan!\n");
    if (-1 == listen(sock_id, 10)) {
        perror("Listen socket failed\n");
        exit(0);
    }
//show_message("lg-->listen ok!\n");
    /* server part commented by guoqingbo*/
//    while (1) {
        clie_addr_len = sizeof(clie_addr);
        link_id = accept(sock_id, (struct sockaddr *)&clie_addr, &clie_addr_len);
        if (-1 == link_id) {
            perror("Accept socket failed\n");
            exit(0);
        }
		

	//��д����
    if ((fp = fopen("1.jpg", "w")) == NULL) {
        perror("Open file failed\n");
        exit(0);
    }
	
//**********************************
		bzero(buf, MAXLINE);		
		//д���ڴ�
        while (recv_len = recv(link_id, buf, MAXLINE, 0)) {
            /* receiver data part commented by guoqingbo*/
            if(recv_len < 0) {
                //show_message("Recieve Data From Server Failed!\n");
                break;
            }
            //show_message("read_file transmission ing......\n");
            write_leng = fwrite(buf, sizeof(char), recv_len, fp);
            if (write_leng < recv_len) {
                //show_message("read_file transmission failed\n");
                break;
            }
            bzero(buf,MAXLINE);
        }
//********************************		
		
        //show_message("\nFinish Recieve\n");
        fclose(fp);
        close(link_id);
//    }
    close(sock_id); 
    return 0;
}

