#ifndef TCP_SERVER_H_
#define TCP_SERVER_H_

extern int tcp_server(int argc, char *argv[]);
extern int send_msg_to_client(unsigned char type, unsigned char code, unsigned char *data, int datalen);
#endif

