#include "list.h"
#include "share.h"

/*������������*/

/**
function����ӡ����
parmater��
     p: ������ʼ��ӡʱ��ָ��
	 score_type����ӡ������ʱ��
return��
	p: ������ӡ���ָ��
*/
struct stu * print_List(struct stu *p,int score_type)
{
	int i=2;
	
	while(p!=NULL)
	{// ��ӡѧ����¼
		
		mvwprintw(main_win,i,1,p->data.sno);	
		mvwprintw(main_win,i,6,p->data.name);	
		
		if(score_type==DEFAULT)
		{
			mvwprintw(main_win,i,28,"%2d",p->data.age);
			mvwprintw(main_win,i,32,"%.1f",p->data.chinese);
			mvwprintw(main_win,i,38,"%.1f",p->data.english);
			mvwprintw(main_win,i,44,"%.1f",p->data.math);
			mvwprintw(main_win,i,50,"%.1f",p->data.physics);
			mvwprintw(main_win,i,57,"%.1f",p->data.chemistry);
			mvwprintw(main_win,i,65,"%.1f",p->data.total);
			mvwprintw(main_win,i,73,"%.1f",p->data.avg);
		}
		else if(score_type==CHIN)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.chinese);
		}
		else if(score_type==ENG)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.english);
		}
		else if(score_type==MATH)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.math);
		}
		else if(score_type==PHY)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.physics);
		}
		else if(score_type==CHEM)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.chemistry);
		}
		else if(score_type==TOTAL)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.total);
		}
		else if(score_type==AVG)
		{
			mvwprintw(main_win,i,32,"%.1f",p->data.avg);
		}
		
		p=p->next;	
		if(i==11)//ÿҳ��ӡʮ����¼
			break;
		i++;
	}

	wrefresh(main_win);
	return p;
}

/**
function������������
parmater��
    head_tmp: ����ͷ�ڵ�ָ��
return��
	count����������
*/
int  link_length(struct stu *head_tmp)
{
	int count=0;
	struct stu *tmp=head_tmp;

	if(head==NULL)
	{
		return count;
	}
	else
	{
		count++;
		while(tmp->next!=NULL)
		{
			count++;
			tmp=tmp->next;
		}
	}
	return count;
}

/**
function�����±���ҽڵ�
parmater��
    head_tmp: ����ͷ�ڵ�ָ��
	index���±�
return��
	count����������
*/
struct stu * get_node_by_index(struct stu *head_tmp,int index)
{
	struct stu *tmp=head_tmp;
	int count=1;

	if(index>0 && index<=record)
	{		
		while(tmp->next!=NULL)
		{
			if(count==index)
				return tmp;
			tmp=tmp->next;	
			count++;
		}
		
		if(count==record)
		{
			return tmp;
		}
	}
	else
	{
		return NULL;
	}
}

/**
function�����������ҽڵ�
parmater��
    sname_tmp: Ҫ���ҵ�����
return��
	tmp�����ҵ��Ľڵ�
*/
struct stu * search_by_Sname(char *sname_tmp)
{
	struct stu *tmp=head;

	while(tmp->next!=NULL)
	{
		if(!strcmp(sname_tmp,tmp->data.name))
			return tmp;
		tmp=tmp->next;	
	}

	if(!strcmp(sname_tmp,tmp->data.name))
	{
		return tmp;
	}

	return NULL;
}

/**
function�����½ڵ�
parmater��
    p: Ҫ���µĽڵ�ָ��
return����
*/
void update_node(struct stu *p,SNode tmp_node)
{
	isSave=1;
	p->data=tmp_node;
}


/**
function��ɾ���ڵ�
parmater��
    p: Ҫɾ���Ľڵ�ָ��
return����
*/
void delete_node(struct stu *p)
{
	struct stu * p_tmp=p->prior,*n_tmp=p->next;
	isSave=1;
	record--;
	if(p_tmp)
		p_tmp->next=p->next;
	if(n_tmp)
		n_tmp->prior=p_tmp;
	p->next=NULL;
	p->prior=NULL;
	free(p);
}

/**
function�����뵽����β��
parmater��
     info:Ҫ����Ľڵ�
return����
*/
void append_List(struct stu *info)
{
	struct stu *tmp=head;
	
	if(tmp==NULL)
	{
		head=info;
		head->next=NULL;
		head->prior=NULL;	
	}
	else
	{
		while(tmp->next!=NULL)
		{
			tmp=tmp->next;
		}
		tmp->next=info;
		info->prior=tmp;
		info->next=NULL;
	}
	record++;
}

/**
function���ͷ�����
parmater����
return����
*/
void free_List()
{
	record=0;
	if(head==NULL)
		return; 
	else 
	{
		while(head->next!=NULL)
		{
			head=head->next;
			head->prior->prior = NULL;
			head->prior->next = NULL;
			free(head->prior);
			head->prior = NULL;
		}
		if(head->next==NULL)
		{
			free(head);
			head = NULL;
		}
	}
}

/**
function��ȡ��chineseƽ����
parmater: ��
return: �ÿ�ƽ����
*/
float get_AVG_chinese()
{
	float count=0;
	struct stu *tmp=head;
	while(tmp!=NULL)
	{
		count+=tmp->data.chinese;
		tmp=tmp->next;	
	}
	
	return (count/record);
}

/**
function��ȡenglishƽ����
parmater: ��
  return: �ÿ�ƽ����
*/
float get_AVG_english()
{
	float count=0;
	struct stu *tmp=head;
	while(tmp!=NULL)
	{
		count+=tmp->data.english;
		tmp=tmp->next;	
	}

	return (count/record);
}

/**
function��ȡmathƽ����
parmater: ��
return: �ÿ�ƽ����
*/
float get_AVG_math()
{
	float count=0;
	struct stu *tmp=head;
	while(tmp!=NULL)
	{
		count+=tmp->data.math;
		tmp=tmp->next;	
	}
	
	return (count/record);
}

/**
function��ȡphysicsƽ����
parmater: ��
return: �ÿ�ƽ����
*/
float get_AVG_physics()
{
	float count=0;
	struct stu *tmp=head;
	while(tmp!=NULL)
	{
		count+=tmp->data.physics;
		tmp=tmp->next;	
	}

	return (count/record);
}

/**
function��ȡchemistryƽ����
parmater: ��
return: �ÿ�ƽ����
*/
float get_AVG_chemistry()
{
	float count=0;
	struct stu *tmp=head;
	while(tmp!=NULL)
	{
		count+=tmp->data.chemistry;
		tmp=tmp->next;	
	}

	return (count/record);
}

/**
function�������ڵ�����
parmater: i,j �ڵ��±�
return: �ÿ�ƽ����
*/
void Swap(int i,int j)
{
	SNode t={0};
	t=list_tmp[i].data;
	list_tmp[i].data=list_tmp[j].data;
	list_tmp[j].data=t;
}

/**
function��ȡ�ɼ�ǰ����
parmater:
	flag: ������������
return: ��
*/
void find_topThree(int flag)
{
	int count=0;
	int thr[3]={0};
	int i,j;
	Desc_order_by_score(flag);

	for(i=0;i<record;i++)
	{
		for(j=i+1;j<record;j++)
		{	
			thr[count]++;
			if(flag==TOTAL)
			{
				if(list_tmp[i].data.total !=list_tmp[j].data.total)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}
			else if(flag==CHIN)
			{
				if(list_tmp[i].data.chinese !=list_tmp[j].data.chinese)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}
			else if(flag==ENG)
			{
				if(list_tmp[i].data.english !=list_tmp[j].data.english)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}
			else if(flag==MATH)
			{
				if(list_tmp[i].data.math !=list_tmp[j].data.math)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}
			else if(flag==PHY)
			{
				if(list_tmp[i].data.physics !=list_tmp[j].data.physics)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}
			else if(flag==CHEM)
			{
				if(list_tmp[i].data.chemistry !=list_tmp[j].data.chemistry)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}
			else if(flag==AVG)
			{
				if(list_tmp[i].data.avg !=list_tmp[j].data.avg)
				{
					count++;				
					if(count==3)
					{
						list_tmp[j-1].next=NULL;
						return;
					}
					i=j-1;
					break;
				}
			}

		}

		if(thr[0]>=3)
		{
			list_tmp[j-1].next=NULL;
			return;
		}
		else if (( thr[0]+thr[1])>=3)
		{
			list_tmp[j-1].next=NULL;
			return;
		}
	}
}


