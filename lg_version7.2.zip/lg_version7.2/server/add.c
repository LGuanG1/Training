#include "add.h"
#include "share.h"

/*ѧ����Ϣ¼�뺯��*/
void add_info()		
{
	int i=0,n=0;
	struct stu * p;   //�����ڵ�
	int age;
	float total=0.0;
	char sno[5];
	char name[21];
	char birthday[11];
	float grade[5];	 //���ڴ�ȡ��5�ųɼ�
	char score[5];
	int ch;
	
	/*�Զ�����δ����ѧ��*/
	do
	{
		i++;
		Auto_Sno(sno,record+i); 		
	}while(search_by_Sno(sno)!=NULL);

	create_title_window("Add Info");
	show_message("Please input the student's name!");
	wclear(main_win);	
    mvwprintw(main_win,1,22,"Sno:");
	mvwprintw(main_win,1,26,sno); 	/*���ѧ��*/
	mvwprintw(main_win,1,47,"[Press Esc to return]");
	mvwprintw(main_win,2,21,"Name:");
	mvwprintw(main_win,2,47,"[only space or letters]");
	mvwprintw(main_win,3,17,"Birthday:");
	mvwprintw(main_win,3,47,"[Age:7~30 Year-month-day]");	
	mvwprintw(main_win,4,18,"Chinese:");
	mvwprintw(main_win,4,47,"[0.0~100.0]");
	mvwprintw(main_win,5,18,"English:");
	mvwprintw(main_win,5,47,"[0.0~100.0]");
	mvwprintw(main_win,6,21,"Math:");
	mvwprintw(main_win,6,47,"[0.0~100.0]");
	mvwprintw(main_win,7,18,"Physics:");
	mvwprintw(main_win,7,47,"[0.0~100.0]");
	mvwprintw(main_win,8,16,"Chemistry:");
	mvwprintw(main_win,8,47,"[0.0~100.0]");
 	wrefresh(main_win);
	
	//��������
	show_message("please input student name!");
	wrefresh(message_win); 
	wmove(main_win,2,26);	  
	do
	{
		memset(name,0,sizeof(name));
		n=get_input_str(main_win,name,20,ASCII_TEXT);	
	}while(!check_name(main_win,name));	

	//��������
	show_message("please input student's birthday!");
	wrefresh(message_win); 
	wmove(main_win,3,26);
	do
	{
		memset(birthday,0,sizeof(birthday));
		n=get_input_str(main_win,birthday,20,ASCII_TEXT);
		age=check_birthday(birthday);
	}while(!age);	


	//������Ƴɼ�
	for(i=0; i<5; i++)
	{
		show_message("please input score!");	
		wrefresh(message_win); 
		wmove(main_win,4+i,26);
		do
		{
			memset(score,0,sizeof(score));
			n=get_input_str(main_win,score,20,ASCII_TEXT);	
		}while(!check_score(main_win,score));	
				
		grade[i]=(float)atof(score);			//���ַ���ת��Ϊ������
		total=total+grade[i];
	}
	
	// ��ѧ����¼��������
	p=(struct stu *)malloc(sizeof(struct stu));
	strcpy(p->data.sno,sno);
	strcpy(p->data.name,name);
	p->data.age=age;
	p->data.chinese=grade[0];
	p->data.english=grade[1];
	p->data.math=grade[2];
	p->data.physics=grade[3];
	p->data.chemistry=grade[4];
	p->data.total=total;
	p->data.avg=p->data.total/5.0;
	
	append_List(p);    //��������β��
	isSave=1;          //���δ����

    wrefresh(main_win); 
	
    /*�ж��Ƿ��������*/ 
	show_message("Add student's information successed!\nDo you want to add another ?[y/n]:");
	
	
	ch=choice_YorN();
	if('y'==ch)
		add_info();
	else 
		menu();
}


