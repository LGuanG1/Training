#ifndef FILE_H_
#define FILE_H_

#include "share.h"

#define DEFAULT_FILE "defaultStudentInfo.ini"
#define LOG_FILE "log.txt"


enum SAVE_FLAG{SAVE_BEFORE,SAVE_EXIT};//��ӡ����
enum CHECK_FILENAME_FLAG{CHECK_SAVE,CHECK_LOAD};//����ļ���ʱ���
enum LOAD_DATA_MENU{ //���ļ�����˵�
	RETURN_MAIN6,FROM_DEFAULT_FILE,FROM_OTHER_FILE};
enum SAVE_DATA_MENU{ //�����¼�˵�
	RETURN_MAIN1,TO_DEFAULT_FILE,TO_OTHER_FILE};

extern int add_to_log_file(char *fmt,...);

	
#define FILE_LOG 1
	
#if FILE_LOG
#define server_print(format, argument...) 	add_to_log_file(format,##argument)
#define server_dbg(format, argument...) 	add_to_log_file("[%s(%d)]==>"format,__FILE__,__LINE__,##argument)
#define server_dbg_err(format, argument...) 	add_to_log_file("[ERR][%s(%d)]==>"format,__FILE__,__LINE__,##argument)
#else
#define server_dbg(format, argument...) 			  0
#define server_dbg_err(format, argument...) 	   0
#endif


extern void save_as_file(int flag);
extern void save_to_file();
extern void load_data();
extern void load_from_other();
extern void save_toFile(char *filename);
extern void read_fromFile(char *filename);
extern void save_data();  

#endif

