#include "sort.h"
#include "share.h"
#include "print.h"

/**
function����ѧ�Ų��ҽڵ�
parmater��
    sno_tmp: Ҫ���ҵ�ѧ��
return��
	tmp�����ҵ��Ľڵ�
*/
struct stu * search_by_Sno(char *sno_tmp)
{
	struct stu *tmp=head;

	while(tmp!=NULL)
	{
		if(!strcmp(sno_tmp,tmp->data.sno))
			return tmp;
		tmp=tmp->next;	
	}

	return NULL;
}

/**
function����ѧ�Ž�������
parmater: ��
return: �ÿ�ƽ����
*/
void Desc_order_by_sno()
{
	struct stu *p=get_node_by_index(head,record);//�ҵ�β��
	int i=0;
	memset(list_tmp,0,sizeof(list_tmp));
	while(p!=NULL)
	{
		list_tmp[i].data=p->data;
		if(i==0)
		{
			list_tmp[i].next=NULL;
			list_tmp[i].prior=NULL;
		}
		else
		{
			list_tmp[i].next=NULL;
			list_tmp[i-1].next=&list_tmp[i];
			list_tmp[i].prior=&list_tmp[i-1];
		}
		
		i++;	
		p=p->prior;//һֱ��ǰ�ҽڵ�
	}
}

void Asc_order_by_totals()
{
	memset(list_tmp,0,sizeof(list_tmp));
	struct stu *p=head;
	int i=0,j=0,k=0;

	while(p!=NULL)
	{
		list_tmp[i].data=p->data;
		if(i==0)
		{
			list_tmp[i].next=NULL;
			list_tmp[i].prior=NULL;
		}
		else
		{
			list_tmp[i-1].next=&list_tmp[i];
			list_tmp[i].prior=&list_tmp[i-1];
			list_tmp[i].next=NULL;
		}	
		i++;	
		p=p->next;
	}
	
	for(j=0;j<i;j++)
		for(k=j;k<i;k++)
		{
			if(list_tmp[j].data.total>list_tmp[k].data.total)
				Swap(j,k);
		}
}


/**
function���ɼ�����������
parmater:
	flag: ������������
return: ��
*/
void Desc_order_by_score(int flag)
{
	memset(list_tmp,0,sizeof(list_tmp));
	struct stu *p=head;
	int i=0,j=0,k=0;
	SNode t={0};
	while(p!=NULL)
	{
		list_tmp[i].data=p->data;
		if(i==0)
		{
			list_tmp[i].next=NULL;
			list_tmp[i].prior=NULL;
		}
		else
		{
			list_tmp[i-1].next=&list_tmp[i];
			list_tmp[i].prior=&list_tmp[i-1];
			list_tmp[i].next=NULL;
		}	
		i++;	
		p=p->next;
	}
	
	if(flag==TOTAL)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.total<list_tmp[k].data.total)
					Swap(j,k);
			}
	}
	else if(flag==CHIN)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.chinese<list_tmp[k].data.chinese)
					Swap(j,k);
			}
	}
	else if(flag==ENG)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.english<list_tmp[k].data.english)
					Swap(j,k);			
			}
	}
	else if(flag==MATH)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.math<list_tmp[k].data.math)
					Swap(j,k);
			
			}
	}
	else if(flag==PHY)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.physics<list_tmp[k].data.physics)
					Swap(j,k);
			}
	}
	else if(flag==CHEM)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.chemistry<list_tmp[k].data.chemistry)
					Swap(j,k);
			}
	}
	else if(flag==AVG)
	{
		for(j=0;j<i;j++)
			for(k=j;k<i;k++)
			{	
				if(list_tmp[j].data.avg<list_tmp[k].data.avg)
					Swap(j,k);
			}
	}
}


/*��¼������*/
void sort_data()	
{	
    int ch;
    
    if(record==0 && head==NULL)
    {
        show_message("Error:No record to sort!\nPress any key to continue....");
        wgetch(title_win);
        menu();
    }

    create_title_window("Sort Menu ");	
    show_message("");

    wclear(main_win);
    mvwprintw(main_win,1,28,"1.Ascending order by sno");
    mvwprintw(main_win,3,28,"2.Descending order by sno");
    mvwprintw(main_win,5,28,"3.Ascending order by totals");
    mvwprintw(main_win,7,28,"4.Descending order by totals");
    mvwprintw(main_win,9,28,"0.Return main menu");
    mvwprintw(main_win,11,28,"Please Make a choices[0-4]:");	
    wrefresh(main_win);

    ch=choice_menu('4');

    ch=ch-'0';
    show_message("Do you want to print the sort list?[y/n]");
    wrefresh(message_win); 	

    switch(ch)
    {
        case ASC_BY_SNO : 		
            ch=choice_YorN();
            if('y'==ch)
                print_report(head,PRINT_SORT,DEFAULT);
            else
                sort_data();
            break;
        case DESC_BY_SNO :
            Desc_order_by_sno();
            ch=choice_YorN();
            if('y'==ch)
                print_report(list_tmp,PRINT_SORT,DEFAULT);
            else
                sort_data();
            break;
        case ASC_BY_TOTALS :
            //Asc_order_by_totals();
            Desc_order_by_score(MATH);
            ch=choice_YorN();
            if('y'==ch)
                print_report(list_tmp,PRINT_SORT,DEFAULT);
            else
                sort_data();
            break;
        case DESC_BY_TOTALS :
            Desc_order_by_score(TOTAL);
            ch=choice_YorN();
            if('y'==ch)
                print_report(list_tmp,PRINT_SORT,DEFAULT);
            else
                sort_data();
            break;
        case RETURN_MAIN2 :
            menu(); 
            break;	
   }
}

