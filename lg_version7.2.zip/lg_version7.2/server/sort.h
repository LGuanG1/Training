#ifndef SORT_H_
#define SORT_H_

#include "list.h"

enum SORT_MENU{      //����˵�
	RETURN_MAIN2,ASC_BY_SNO,DESC_BY_SNO,ASC_BY_TOTALS,DESC_BY_TOTALS};

extern struct stu * search_by_Sno(char *sno_tmp);
extern void Desc_order_by_sno();
extern void Asc_order_by_totals();
extern void Desc_order_by_score(int flag);
extern void sort_data();
#endif

